python Bamsnap-LRS/bin/bamsnap-lrs rna \
	--bam test.rna.bam \
	--pos Cdec_SDR_X:280000-290000 \
	--out test.rna.part.svg \
	--fa ref.fasta \
	--show-axis \
	--width 700

echo -e "Cdec_SDR_X\t280000\t290000\tmRNA1" > target.bed
/home/stereonote/SVhawkeye/hawkeye.py rna_browse -i  test.rna.bam -b target.bed -r ref.fasta -o rna  -F pdf -d 0 -g ref