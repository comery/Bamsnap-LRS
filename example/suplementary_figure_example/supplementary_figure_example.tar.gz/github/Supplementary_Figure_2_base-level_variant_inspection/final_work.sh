#!/bin/bash

# ====================== auto check FASTA file ======================
FASTA_FILE="chm13v2.0.fasta"

if [ -f "$FASTA_FILE" ]; then
    echo "reference exist $FASTA_FILE, run bamsnap-lrs command with --fa"
    FASTA_ARG="--fa $FASTA_FILE"
else
    echo "no reference $FASTA_FILE, run bamsnap-lrs command no --fa"
    echo "reference can download from https://s3-us-west-2.amazonaws.com/human-pangenomics/T2T/CHM13/assemblies/analysis_set/chm13v2.0.fa.gz"
    FASTA_ARG=""
fi

python Bamsnap-LRS/bin/bamsnap-lrs dna --bam variant_inspection.bam --pos chr1:121406286-121416286  --out bamsnap-lrs.svg   --show-coverage --width 700  --show-axis --read-height 10 $FASTA_ARG

echo -e "chr1\t121406286\t121416286" > target.bed
SVhawkeye/hawkeye.py sv_browse -i variant_inspection.bam -b target.bed -f bed -o ./svhawkeye -t 1 -r $FASTA_FILE  -F pdf -g chm13 -d 0
