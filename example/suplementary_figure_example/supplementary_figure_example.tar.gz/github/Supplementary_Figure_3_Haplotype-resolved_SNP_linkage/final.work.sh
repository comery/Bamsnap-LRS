python Bamsnap-LRS/bin/bamsnap-lrs highlight   --highlight-vcf example.vcf \
  --bam example_reads.bam  \
  --pos scaffold1:0-500  --out highlight.svg --fa example_ref.fa --read-height 9 --width 700
  

echo -e "scaffold1\t0\t500" > target.bed
SVhawkeye/hawkeye.py sv_browse -i  example_reads.bam -b target.bed  -f bed -t 1 -r example_ref.fa  -g chm13 -o svhawkeye_hap -d 0 -F pdf

