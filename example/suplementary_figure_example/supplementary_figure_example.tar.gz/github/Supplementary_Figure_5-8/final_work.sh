#!/bin/bash

# ====================== auto check FASTA file ======================
FASTA_FILE="chm13v2.0.fasta"

if [ -f "$FASTA_FILE" ]; then
    echo "reference exist $FASTA_FILE, run bamsnap-lrs command with --fa"
    FASTA_ARG="--fa $FASTA_FILE"
else
    echo "no reference $FASTA_FILE, run bamsnap-lrs command no --fa"
    echo "reference can download from https://s3-us-west-2.amazonaws.com/human-pangenomics/T2T/CHM13/assemblies/analysis_set/chm13v2.0.fa.gz"
    FASTA_ARG=""
fi


###### SV 
# insertion chrX_26021620_26022120
python Bamsnap-LRS/bin/bamsnap-lrs dna --bam Bamsnap-LRS/example/SV_show/insertion.ONT.bam --regions Bamsnap-LRS/example/SV_show/insertion.vcf  --out-prefix insertion.onebam.detail.svg   --show-coverage  --fa $FASTA_FILE  --padding 250 --width 700  --detail high --show-axis --read-height 9

# deletion
python Bamsnap-LRS/bin/bamsnap-lrs dna --bam Bamsnap-LRS/example/SV_show/deletion.HIFI.bam --regions Bamsnap-LRS/example/SV_show/deletion.vcf  --out-prefix deletion.onebam.svg   --show-coverage  --fa $FASTA_FILE --width 700  --show-axis --read-height 12

# duplication
python Bamsnap-LRS/bin/bamsnap-lrs dna --bam Bamsnap-LRS/example/SV_show/duplication.HIFI.bam --regions Bamsnap-LRS/example/SV_show/duplication.vcf --out-prefix duplication.svg  --show-coverage --show-supp --fa $FASTA_FILE --width 700   --show-axis --read-height 9

# inversion
python Bamsnap-LRS/bin/bamsnap-lrs dna --bam Bamsnap-LRS/example/SV_show/inversion.HIFI.bam --regions Bamsnap-LRS/example/SV_show/inversion.vcf --out-prefix inversion.svg --show-coverage --show-supp --fa $FASTA_FILE --width 700   --show-axis

##SVhawkeye
# insertion
SVhawkeye/hawkeye.py sv_browse -i  Bamsnap-LRS/example/SV_show/insertion.ONT.bam -b Bamsnap-LRS/example/SV_show/insertion.vcf  -f vcf -t 1 -r $FASTA_FILE -g chm13 -o sv.example -d 250 -F pdf

# deletion
SVhawkeye/hawkeye.py sv_browse -i  Bamsnap-LRS/example/SV_show/deletion.HIFI.bam -b Bamsnap-LRS/example/SV_show/deletion.vcf  -f vcf -t 1 -r $FASTA_FILE -g chm13 -o sv.example  -F pdf

# duplication
SVhawkeye/hawkeye.py sv_browse -i  Bamsnap-LRS/example/SV_show/duplication.HIFI.bam -b Bamsnap-LRS/example/SV_show/duplication.vcf  -f vcf -t 1 -r $FASTA_FILE -g chm13 -o sv.example  -F pdf

# inversion
SVhawkeye/hawkeye.py sv_browse -i  Bamsnap-LRS/example/SV_show/inversion.HIFI.bam -b Bamsnap-LRS/example/SV_show/inversion.vcf  -f vcf -t 1 -r $FASTA_FILE -g chm13 -o sv.example  -F pdf

