####final region  chr5:705000-710000

#!/bin/bash

# ====================== auto check FASTA file ======================
FASTA_FILE="chm13v2.0.fasta"

if [ -f "$FASTA_FILE" ]; then
    echo "reference exist $FASTA_FILE, run bamsnap-lrs command with --fa"
    FASTA_ARG="--fa $FASTA_FILE"
else
    echo "no reference $FASTA_FILE, run bamsnap-lrs command no --fa"
    echo "reference can download from https://s3-us-west-2.amazonaws.com/human-pangenomics/T2T/CHM13/assemblies/analysis_set/chm13v2.0.fa.gz"
    FASTA_ARG=""
fi


python Bamsnap-LRS/bin/bamsnap-lrs dna --bam assembly_validation.bam  --pos chr5:705000-710000 --out assembly_exam.svg   --show-coverage  --width 700  --show-axis  --mapq 60  $FASTA_ARG

echo -e "chr5\t705000\t710000" > target.bed
SVhawkeye/hawkeye.py sv_browse -i  assembly_validation.bam -b target.bed  -f bed -g chm13 -o assem_valid -d 0 -F pdf -r $FASTA_FILE
